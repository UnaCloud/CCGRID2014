#!/bin/bash
cd /unacloud/cluster
sh runIozone.sh > uc0.out 2> uc0.err

