#!/bin/bash
cd /tmp
iozone -a > /unacloud/cluster/results`hostname`.txt